# Alaina's TryOn App — Google Play Store Submission Guide

## App Details
- **App Name:** Alaina's TryOn App
- **Package ID:** com.alaina.tryonapp
- **Version:** 1.0.0 (versionCode 1)
- **Min Android:** 8.0 (API 26)
- **Target Android:** Android 16 (API 36)

---

## Step 1: Set Up Google Play Developer Account
1. Go to https://play.google.com/console
2. Pay the one-time $25 registration fee
3. Complete identity verification (government ID required)
4. Fill in your developer profile

---

## Step 2: Build the App in Android Studio
1. Install Android Studio from https://developer.android.com/studio
2. Open the `android/` folder in Android Studio
3. Go to **Build → Generate Signed Bundle / APK**
4. Choose **Android App Bundle (.aab)** — required by Play Store
5. Create a new keystore (SAVE THIS FILE — you can never update the app without it!)
6. Build the release AAB

---

## Step 3: Closed Testing (Required for New Accounts)
New developer accounts must run closed testing for **14 days with 12+ testers**:
1. In Play Console → Testing → Closed Testing → Create track
2. Add 12 tester email addresses
3. Share the opt-in link with testers
4. Wait 14 days with testers actively using the app

---

## Step 4: Create Store Listing
Fill in Play Console with:

### App Info
- **Name:** Alaina's TryOn App *(50 chars max)*
- **Short description:** Try on any outfit with AI before you buy it *(80 chars)*
- **Full description:** See below

### Full Description (copy-paste ready):
```
Alaina's TryOn App is your personal AI-powered virtual fitting room. 
Upload any clothing item and a photo of yourself — our AI instantly shows 
you how the outfit looks on you.

✦ NO more buying clothes that don't fit
✦ Upload any product photo or screenshot
✦ See a realistic try-on in seconds
✦ Save and share your looks
✦ Your photos are NEVER stored

How it works:
1. Upload a photo of clothing (from any store or website)
2. Upload a photo of yourself
3. AI generates your virtual try-on
4. Decide to buy with confidence

Stop returning clothes. Start shopping smarter with Alaina's TryOn App.
```

### Assets Required
| Asset | Size | File |
|-------|------|------|
| App icon | 512×512 PNG | playstore-icon.png ✓ |
| Feature graphic | 1024×500 PNG | playstore-feature-graphic.png ✓ |
| Screenshots | 2–8 × 1080×1920 PNG | Take from running app |

---

## Step 5: Complete Required Forms
In Play Console, complete these (all required):
- ✅ **Data safety** — declare camera/photo access, no data sold
- ✅ **Content rating** — fill IARC questionnaire (Everyone rating)
- ✅ **Target audience** — 18+ (uses AI image processing)
- ✅ **Privacy policy URL** — host privacy-policy.html publicly (e.g. GitHub Pages)

---

## Step 6: Submit for Review
- Review typically takes **3–7 days** for new apps
- You'll receive an email when approved or if changes are needed

---

## Keystore Warning ⚠️
Back up your keystore (.jks) file immediately after creating it.
Without it, you can NEVER push updates to your app on the Play Store.
