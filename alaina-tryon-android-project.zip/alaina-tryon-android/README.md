# Alaina's TryOn App — Android Project

AI-powered virtual clothing try-on app built with Capacitor + WebView.

## Project Info
- **App Name:** Alaina's TryOn App  
- **Package:** com.alaina.tryonapp  
- **Version:** 1.0.0  
- **Min Android:** 5.0 (API 21)  
- **Target Android:** API 34

---

## ⚡ Fastest Way: Build APK via GitHub Actions (FREE, no install needed)

1. Create a free account at **github.com**
2. Create a new repository → upload this entire folder
3. Go to **Actions** tab → click **"Build Alaina TryOn APK"** → **"Run workflow"**
4. Wait ~5 minutes → download the APK from **Artifacts**

---

## 🖥️ Build Locally with Android Studio

1. Install **Android Studio** → developer.android.com/studio
2. Open this project's `android/` folder
3. Let it sync Gradle (first time takes ~5 min)
4. **Build → Build Bundle(s)/APK(s) → Build APK(s)**
5. APK is at: `android/app/build/outputs/apk/debug/app-debug.apk`

---

## ☁️ Build via Codemagic (No Android Studio needed)

1. Go to **codemagic.io** → sign in with GitHub
2. Add this repository
3. It auto-detects `codemagic.yaml` and builds
4. Download APK from build results

---

## Install APK on Android Phone

1. Transfer APK to your phone
2. Go to **Settings → Security → Unknown Sources** → Enable
3. Open the APK file → Install
4. Open **Alaina's TryOn App** 🎉
