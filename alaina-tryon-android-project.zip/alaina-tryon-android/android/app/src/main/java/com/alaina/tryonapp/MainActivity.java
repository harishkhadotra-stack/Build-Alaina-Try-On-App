package com.alaina.tryonapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
